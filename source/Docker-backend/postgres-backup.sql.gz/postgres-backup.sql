--
-- PostgreSQL database dump
--

-- Dumped from database version 13.0
-- Dumped by pg_dump version 13.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: abonos_abono; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.abonos_abono (
    id bigint NOT NULL,
    abono integer NOT NULL,
    date_created date NOT NULL,
    prestamo_id bigint NOT NULL,
    CONSTRAINT abonos_abono_abono_check CHECK ((abono >= 0))
);


ALTER TABLE public.abonos_abono OWNER TO pawnshop;

--
-- Name: abonos_abono_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.abonos_abono_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.abonos_abono_id_seq OWNER TO pawnshop;

--
-- Name: abonos_abono_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.abonos_abono_id_seq OWNED BY public.abonos_abono.id;


--
-- Name: adicionales_adicional; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.adicionales_adicional (
    id bigint NOT NULL,
    adicional integer NOT NULL,
    date_created date NOT NULL,
    prestamo_id bigint NOT NULL,
    CONSTRAINT adicionales_adicional_adicional_check CHECK ((adicional >= 0))
);


ALTER TABLE public.adicionales_adicional OWNER TO pawnshop;

--
-- Name: adicionales_adicional_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.adicionales_adicional_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.adicionales_adicional_id_seq OWNER TO pawnshop;

--
-- Name: adicionales_adicional_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.adicionales_adicional_id_seq OWNED BY public.adicionales_adicional.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO pawnshop;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO pawnshop;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO pawnshop;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO pawnshop;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO pawnshop;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO pawnshop;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: clients_client; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.clients_client (
    id bigint NOT NULL,
    nombre character varying(200) NOT NULL,
    apellido character varying(200) NOT NULL,
    cedula character varying(10) NOT NULL,
    telefono character varying(10) NOT NULL,
    direccion character varying(200) NOT NULL,
    direccion2 character varying(200) NOT NULL,
    ref1 character varying(200) NOT NULL,
    telefono_ref1 character varying(10) NOT NULL,
    creador_id bigint,
    fecha_creacion date NOT NULL,
    status boolean NOT NULL
);


ALTER TABLE public.clients_client OWNER TO pawnshop;

--
-- Name: clients_client_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.clients_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clients_client_id_seq OWNER TO pawnshop;

--
-- Name: clients_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.clients_client_id_seq OWNED BY public.clients_client.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO pawnshop;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO pawnshop;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO pawnshop;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO pawnshop;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO pawnshop;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO pawnshop;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO pawnshop;

--
-- Name: loans_loan; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.loans_loan (
    id bigint NOT NULL,
    monto_prestado integer NOT NULL,
    interes double precision NOT NULL,
    num_meses integer NOT NULL,
    date_created date NOT NULL,
    num_cuotas integer NOT NULL,
    deadline date NOT NULL,
    status boolean NOT NULL,
    last_modification date NOT NULL,
    monto_adeudado integer NOT NULL,
    cliente_id bigint NOT NULL,
    tipo_pago_id bigint NOT NULL,
    creador_id bigint,
    CONSTRAINT loans_loan_monto_adeudado_check CHECK ((monto_adeudado >= 0)),
    CONSTRAINT loans_loan_monto_prestado_check CHECK ((monto_prestado >= 0)),
    CONSTRAINT loans_loan_num_cuotas_check CHECK ((num_cuotas >= 0)),
    CONSTRAINT loans_loan_num_meses_check CHECK ((num_meses >= 0))
);


ALTER TABLE public.loans_loan OWNER TO pawnshop;

--
-- Name: loans_loan_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.loans_loan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.loans_loan_id_seq OWNER TO pawnshop;

--
-- Name: loans_loan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.loans_loan_id_seq OWNED BY public.loans_loan.id;


--
-- Name: loans_tipopago; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.loans_tipopago (
    id bigint NOT NULL,
    tipo character varying(200) NOT NULL
);


ALTER TABLE public.loans_tipopago OWNER TO pawnshop;

--
-- Name: loans_tipopago_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.loans_tipopago_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.loans_tipopago_id_seq OWNER TO pawnshop;

--
-- Name: loans_tipopago_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.loans_tipopago_id_seq OWNED BY public.loans_tipopago.id;


--
-- Name: users_customuser; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.users_customuser (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    age integer NOT NULL,
    CONSTRAINT users_customuser_age_check CHECK ((age >= 0))
);


ALTER TABLE public.users_customuser OWNER TO pawnshop;

--
-- Name: users_customuser_groups; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.users_customuser_groups (
    id bigint NOT NULL,
    customuser_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_customuser_groups OWNER TO pawnshop;

--
-- Name: users_customuser_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.users_customuser_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_customuser_groups_id_seq OWNER TO pawnshop;

--
-- Name: users_customuser_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.users_customuser_groups_id_seq OWNED BY public.users_customuser_groups.id;


--
-- Name: users_customuser_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.users_customuser_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_customuser_id_seq OWNER TO pawnshop;

--
-- Name: users_customuser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.users_customuser_id_seq OWNED BY public.users_customuser.id;


--
-- Name: users_customuser_user_permissions; Type: TABLE; Schema: public; Owner: pawnshop
--

CREATE TABLE public.users_customuser_user_permissions (
    id bigint NOT NULL,
    customuser_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_customuser_user_permissions OWNER TO pawnshop;

--
-- Name: users_customuser_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: pawnshop
--

CREATE SEQUENCE public.users_customuser_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_customuser_user_permissions_id_seq OWNER TO pawnshop;

--
-- Name: users_customuser_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawnshop
--

ALTER SEQUENCE public.users_customuser_user_permissions_id_seq OWNED BY public.users_customuser_user_permissions.id;


--
-- Name: abonos_abono id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.abonos_abono ALTER COLUMN id SET DEFAULT nextval('public.abonos_abono_id_seq'::regclass);


--
-- Name: adicionales_adicional id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.adicionales_adicional ALTER COLUMN id SET DEFAULT nextval('public.adicionales_adicional_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: clients_client id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.clients_client ALTER COLUMN id SET DEFAULT nextval('public.clients_client_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: loans_loan id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.loans_loan ALTER COLUMN id SET DEFAULT nextval('public.loans_loan_id_seq'::regclass);


--
-- Name: loans_tipopago id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.loans_tipopago ALTER COLUMN id SET DEFAULT nextval('public.loans_tipopago_id_seq'::regclass);


--
-- Name: users_customuser id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser ALTER COLUMN id SET DEFAULT nextval('public.users_customuser_id_seq'::regclass);


--
-- Name: users_customuser_groups id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser_groups ALTER COLUMN id SET DEFAULT nextval('public.users_customuser_groups_id_seq'::regclass);


--
-- Name: users_customuser_user_permissions id; Type: DEFAULT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_customuser_user_permissions_id_seq'::regclass);


--
-- Data for Name: abonos_abono; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.abonos_abono (id, abono, date_created, prestamo_id) FROM stdin;
\.


--
-- Data for Name: adicionales_adicional; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.adicionales_adicional (id, adicional, date_created, prestamo_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add content type	4	add_contenttype
14	Can change content type	4	change_contenttype
15	Can delete content type	4	delete_contenttype
16	Can view content type	4	view_contenttype
17	Can add session	5	add_session
18	Can change session	5	change_session
19	Can delete session	5	delete_session
20	Can view session	5	view_session
21	Can add user	6	add_customuser
22	Can change user	6	change_customuser
23	Can delete user	6	delete_customuser
24	Can view user	6	view_customuser
25	Can add client	7	add_client
26	Can change client	7	change_client
27	Can delete client	7	delete_client
28	Can view client	7	view_client
29	Can add tipo pago	8	add_tipopago
30	Can change tipo pago	8	change_tipopago
31	Can delete tipo pago	8	delete_tipopago
32	Can view tipo pago	8	view_tipopago
33	Can add loan	9	add_loan
34	Can change loan	9	change_loan
35	Can delete loan	9	delete_loan
36	Can view loan	9	view_loan
37	Can add abono	10	add_abono
38	Can change abono	10	change_abono
39	Can delete abono	10	delete_abono
40	Can view abono	10	view_abono
41	Can add adicional	11	add_adicional
42	Can change adicional	11	change_adicional
43	Can delete adicional	11	delete_adicional
44	Can view adicional	11	view_adicional
\.


--
-- Data for Name: clients_client; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.clients_client (id, nombre, apellido, cedula, telefono, direccion, direccion2, ref1, telefono_ref1, creador_id, fecha_creacion, status) FROM stdin;
1	Victor	Tilve	1143376273	3213543135	sdrgwethweth	asrgeargqe	adrsthwrt	6654313543	\N	2022-03-09	t
2	Luis	Tilve	3354354135	3535435313	asrgrgeqrg	3sdrtghweth	gsdrsdrfghsdhsdth	3543543543	\N	2022-03-09	t
3	Jamirlley	Tilve	3543433134	3543543534	a3rshwrht54354	sd3r5h4th354	sdghsdthsrt	3543543645	\N	2022-03-09	t
4	Mary	Salgado	6543133213	3543543454	aghwethwrjrt	sdtherjwrj	drhwrrtjwrj6t	3545354354	\N	2022-03-09	t
5	Rayshell	Ramirez	3543543545	3543543543	wethwrtjwryj	wterjywj	sfgjhrtyuwer6	3535135413	\N	2022-03-09	t
6	Salomé	Zuluaga	6465464654	6546545641	rstjhwrtjwr	hstjrtwt	stdhstjdyj	5435435435	\N	2022-03-09	t
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	users	customuser
7	clients	client
8	loans	tipopago
9	loans	loan
10	abonos	abono
11	adicionales	adicional
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	clients	0001_initial	2022-03-09 02:05:11.026224+00
2	loans	0001_initial	2022-03-09 02:05:11.05363+00
3	abonos	0001_initial	2022-03-09 02:05:11.063194+00
4	abonos	0002_abono_prestamo	2022-03-09 02:05:11.07698+00
5	contenttypes	0001_initial	2022-03-09 02:05:11.092461+00
6	contenttypes	0002_remove_content_type_name	2022-03-09 02:05:11.101602+00
7	auth	0001_initial	2022-03-09 02:05:11.176872+00
8	auth	0002_alter_permission_name_max_length	2022-03-09 02:05:11.18443+00
9	auth	0003_alter_user_email_max_length	2022-03-09 02:05:11.192772+00
10	auth	0004_alter_user_username_opts	2022-03-09 02:05:11.200903+00
11	auth	0005_alter_user_last_login_null	2022-03-09 02:05:11.2088+00
12	auth	0006_require_contenttypes_0002	2022-03-09 02:05:11.212244+00
13	auth	0007_alter_validators_add_error_messages	2022-03-09 02:05:11.218527+00
14	auth	0008_alter_user_username_max_length	2022-03-09 02:05:11.225691+00
15	auth	0009_alter_user_last_name_max_length	2022-03-09 02:05:11.232919+00
16	auth	0010_alter_group_name_max_length	2022-03-09 02:05:11.240145+00
17	auth	0011_update_proxy_permissions	2022-03-09 02:05:11.248338+00
18	auth	0012_alter_user_first_name_max_length	2022-03-09 02:05:11.255159+00
19	users	0001_initial	2022-03-09 02:05:11.334913+00
20	loans	0002_initial	2022-03-09 02:05:11.378961+00
21	loans	0003_auto_20220129_2107	2022-03-09 02:05:11.422782+00
22	loans	0004_remove_loan_monto_a_pagar	2022-03-09 02:05:11.431445+00
23	loans	0005_alter_loan_options	2022-03-09 02:05:11.441148+00
24	adicionales	0001_initial	2022-03-09 02:05:11.470385+00
25	admin	0001_initial	2022-03-09 02:05:11.50569+00
26	admin	0002_logentry_remove_auto_add	2022-03-09 02:05:11.51428+00
27	admin	0003_logentry_add_action_flag_choices	2022-03-09 02:05:11.524248+00
28	clients	0002_auto_20220129_2025	2022-03-09 02:05:11.558112+00
29	clients	0003_alter_client_creador	2022-03-09 02:05:11.572346+00
30	sessions	0001_initial	2022-03-09 02:05:11.604326+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Data for Name: loans_loan; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.loans_loan (id, monto_prestado, interes, num_meses, date_created, num_cuotas, deadline, status, last_modification, monto_adeudado, cliente_id, tipo_pago_id, creador_id) FROM stdin;
\.


--
-- Data for Name: loans_tipopago; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.loans_tipopago (id, tipo) FROM stdin;
\.


--
-- Data for Name: users_customuser; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.users_customuser (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, age) FROM stdin;
\.


--
-- Data for Name: users_customuser_groups; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.users_customuser_groups (id, customuser_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_customuser_user_permissions; Type: TABLE DATA; Schema: public; Owner: pawnshop
--

COPY public.users_customuser_user_permissions (id, customuser_id, permission_id) FROM stdin;
\.


--
-- Name: abonos_abono_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.abonos_abono_id_seq', 1, false);


--
-- Name: adicionales_adicional_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.adicionales_adicional_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 44, true);


--
-- Name: clients_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.clients_client_id_seq', 6, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 11, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 30, true);


--
-- Name: loans_loan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.loans_loan_id_seq', 1, false);


--
-- Name: loans_tipopago_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.loans_tipopago_id_seq', 1, false);


--
-- Name: users_customuser_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.users_customuser_groups_id_seq', 1, false);


--
-- Name: users_customuser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.users_customuser_id_seq', 1, false);


--
-- Name: users_customuser_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawnshop
--

SELECT pg_catalog.setval('public.users_customuser_user_permissions_id_seq', 1, false);


--
-- Name: abonos_abono abonos_abono_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.abonos_abono
    ADD CONSTRAINT abonos_abono_pkey PRIMARY KEY (id);


--
-- Name: adicionales_adicional adicionales_adicional_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.adicionales_adicional
    ADD CONSTRAINT adicionales_adicional_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: clients_client clients_client_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.clients_client
    ADD CONSTRAINT clients_client_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: loans_loan loans_loan_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.loans_loan
    ADD CONSTRAINT loans_loan_pkey PRIMARY KEY (id);


--
-- Name: loans_tipopago loans_tipopago_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.loans_tipopago
    ADD CONSTRAINT loans_tipopago_pkey PRIMARY KEY (id);


--
-- Name: users_customuser_groups users_customuser_groups_customuser_id_group_id_76b619e3_uniq; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser_groups
    ADD CONSTRAINT users_customuser_groups_customuser_id_group_id_76b619e3_uniq UNIQUE (customuser_id, group_id);


--
-- Name: users_customuser_groups users_customuser_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser_groups
    ADD CONSTRAINT users_customuser_groups_pkey PRIMARY KEY (id);


--
-- Name: users_customuser users_customuser_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser
    ADD CONSTRAINT users_customuser_pkey PRIMARY KEY (id);


--
-- Name: users_customuser_user_permissions users_customuser_user_pe_customuser_id_permission_7a7debf6_uniq; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser_user_permissions
    ADD CONSTRAINT users_customuser_user_pe_customuser_id_permission_7a7debf6_uniq UNIQUE (customuser_id, permission_id);


--
-- Name: users_customuser_user_permissions users_customuser_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser_user_permissions
    ADD CONSTRAINT users_customuser_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_customuser users_customuser_username_key; Type: CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser
    ADD CONSTRAINT users_customuser_username_key UNIQUE (username);


--
-- Name: abonos_abono_prestamo_id_9485b743; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX abonos_abono_prestamo_id_9485b743 ON public.abonos_abono USING btree (prestamo_id);


--
-- Name: adicionales_adicional_prestamo_id_d694e056; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX adicionales_adicional_prestamo_id_d694e056 ON public.adicionales_adicional USING btree (prestamo_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: clients_client_creador_id_04ddc6da; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX clients_client_creador_id_04ddc6da ON public.clients_client USING btree (creador_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: loans_loan_cliente_id_5c4aac82; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX loans_loan_cliente_id_5c4aac82 ON public.loans_loan USING btree (cliente_id);


--
-- Name: loans_loan_creador_id_dae792e8; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX loans_loan_creador_id_dae792e8 ON public.loans_loan USING btree (creador_id);


--
-- Name: loans_loan_tipo_pago_id_c56b3995; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX loans_loan_tipo_pago_id_c56b3995 ON public.loans_loan USING btree (tipo_pago_id);


--
-- Name: users_customuser_groups_customuser_id_958147bf; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX users_customuser_groups_customuser_id_958147bf ON public.users_customuser_groups USING btree (customuser_id);


--
-- Name: users_customuser_groups_group_id_01390b14; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX users_customuser_groups_group_id_01390b14 ON public.users_customuser_groups USING btree (group_id);


--
-- Name: users_customuser_user_permissions_customuser_id_5771478b; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX users_customuser_user_permissions_customuser_id_5771478b ON public.users_customuser_user_permissions USING btree (customuser_id);


--
-- Name: users_customuser_user_permissions_permission_id_baaa2f74; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX users_customuser_user_permissions_permission_id_baaa2f74 ON public.users_customuser_user_permissions USING btree (permission_id);


--
-- Name: users_customuser_username_80452fdf_like; Type: INDEX; Schema: public; Owner: pawnshop
--

CREATE INDEX users_customuser_username_80452fdf_like ON public.users_customuser USING btree (username varchar_pattern_ops);


--
-- Name: abonos_abono abonos_abono_prestamo_id_9485b743_fk_loans_loan_id; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.abonos_abono
    ADD CONSTRAINT abonos_abono_prestamo_id_9485b743_fk_loans_loan_id FOREIGN KEY (prestamo_id) REFERENCES public.loans_loan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adicionales_adicional adicionales_adicional_prestamo_id_d694e056_fk_loans_loan_id; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.adicionales_adicional
    ADD CONSTRAINT adicionales_adicional_prestamo_id_d694e056_fk_loans_loan_id FOREIGN KEY (prestamo_id) REFERENCES public.loans_loan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clients_client clients_client_creador_id_04ddc6da_fk_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.clients_client
    ADD CONSTRAINT clients_client_creador_id_04ddc6da_fk_users_customuser_id FOREIGN KEY (creador_id) REFERENCES public.users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_customuser_id FOREIGN KEY (user_id) REFERENCES public.users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: loans_loan loans_loan_cliente_id_5c4aac82_fk_clients_client_id; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.loans_loan
    ADD CONSTRAINT loans_loan_cliente_id_5c4aac82_fk_clients_client_id FOREIGN KEY (cliente_id) REFERENCES public.clients_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: loans_loan loans_loan_creador_id_dae792e8_fk_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.loans_loan
    ADD CONSTRAINT loans_loan_creador_id_dae792e8_fk_users_customuser_id FOREIGN KEY (creador_id) REFERENCES public.users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: loans_loan loans_loan_tipo_pago_id_c56b3995_fk_loans_tipopago_id; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.loans_loan
    ADD CONSTRAINT loans_loan_tipo_pago_id_c56b3995_fk_loans_tipopago_id FOREIGN KEY (tipo_pago_id) REFERENCES public.loans_tipopago(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_customuser_groups users_customuser_gro_customuser_id_958147bf_fk_users_cus; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser_groups
    ADD CONSTRAINT users_customuser_gro_customuser_id_958147bf_fk_users_cus FOREIGN KEY (customuser_id) REFERENCES public.users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_customuser_groups users_customuser_groups_group_id_01390b14_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser_groups
    ADD CONSTRAINT users_customuser_groups_group_id_01390b14_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_customuser_user_permissions users_customuser_use_customuser_id_5771478b_fk_users_cus; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser_user_permissions
    ADD CONSTRAINT users_customuser_use_customuser_id_5771478b_fk_users_cus FOREIGN KEY (customuser_id) REFERENCES public.users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_customuser_user_permissions users_customuser_use_permission_id_baaa2f74_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: pawnshop
--

ALTER TABLE ONLY public.users_customuser_user_permissions
    ADD CONSTRAINT users_customuser_use_permission_id_baaa2f74_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

